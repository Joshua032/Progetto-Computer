#include "stdafx.h"
#include "Computer.h"
#include "Computer.cpp"
#include "Magazzino.h"
#include "Magazzino.cpp"
#include <string>
#include <cstdio>
#include <iostream>
using namespace std;

/*!		\file programmaComputer.cpp
		\author Joshua Ganzaroli
		\date 19/03/2021
		\class Main
		\details Il programma e' stato sviluppato con l'intenzione di gestire un magazzino di una azienda che cataloga ogni computer dei propri impiegati. 
				 All'interno del programma stesso sono state inserite delle funzioni che permettono l'inserimento di un pc e le sue caratteristiche principali,
				 quali la sua velocita', la grandezza dello schermo, la casa produttrice e cosi' via, funzioni che permettono la ricerca di un determinato computer
				 tramite determinati parametri come ad esempio il codice univoco assegnatogli al momento della registrazione nel catalogo oppure che ricercano 
				 il PC con la migliore velocita', grandezza dello schermo,... Inoltre abbiamo una funzione che ci permette di eliminare un computer dal catalogo tramite
				 codice del computer e un'altra funzione che permette la stampa di tutti i computer presenti.
*/

int main()
{
	int numero = 0;
	int i = 0;

	string marca, modello;
	int velocita = 0, ram = 0, disco = 0, pollici = 0, anno = 0, codice = 1;
	Computer pc;
	Magazzino gestione;

	cout << "CATALOGO COMPUTER DEI DIPENDENTI" << endl;
	
	do
    {
        do
        {
			cout << "1) Aggiungi un computer al catalogo;" << endl;
			cout << "2) Ricerca di un computer tramite un codice univoco;" << endl;
			cout << "3) Ricerca del miglior computer;" << endl;
			cout << "4) Eliminazione di un computer dal catalogo;" << endl;
			cout << "5) Stampa del catalogo intero;" << endl;
			cout << "6) Esci dal programma;" << endl;
            cout << "SCEGLI UNA OPERAZIONE DA SVOLGERE':" << endl;
            cin >> numero;
			cout << "\n" << endl;
        }while(numero<1 || numero>6);
        switch(numero)
        {
            case 1:
                {
					cout << "Inserisci la casa produttrice del pc: "<< endl;
					cin >> marca; 
					cout << "Inserisci il modello: " << endl;
					cin >>  modello;
					cout << "Inserisci la velocita processore (GigaHertz): " << endl;
					cin >> velocita;
					cout << "Inserisci la grandezza della RAM (GB)" << endl;
					cin >> ram;
					cout << "Inserisci la dimensione del disco del pc (GB)" << endl;
					cin >> disco;
					cout << "Inserisci la dimensione del monitor del pc (pollici)" << endl;
					cin >> pollici;
					cout << "Inserisci l'anno di acquisto del pc" << endl;
					cin >> anno;
					
					pc = Computer(marca, modello, velocita, ram, disco, pollici, anno, i);
					
					gestione.aggiungiComputer(pc, i);
                    
					cout << "Il pc e' stato inserito nel catalogo" << endl;
					i++;
					break;
                }

            case 2:
                {
                    
					cout << "Inserisci il codice del pc da cercare, se il pc � presente verranno presentate le sue caratteristiche" << endl;
					cin >> codice;
					gestione.ricercaCodice(codice);

                    break;
                }

            case 3:
                {

					cout << "Il pc con maggiore velocita del processore" << endl;
					gestione.ricercaMiglioreVelocita();					
					cout << "" << endl;

					cout << "Il pc con piu' RAM" << endl;
					gestione.ricercaMiglioreDimensione();
					cout << "" << endl;

					cout << "Il pc con piu' memoria ROM" << endl;
					gestione.ricercaMiglioreDisco();

                    break;
                }

            case 4:
                {                 
					cout << "Inserisci il codice del pc da eliminare" << endl;
					cin >> codice;
					gestione.elimina(codice);

					cout << "Il pc e\' stato eliminato" << endl;

                    break;
                }
            case 5:
                {
                    gestione.stampa();
                    break;
                }

			case 6:
                {
                    return 0;
                    break;
                }
        }
    }while(numero != 6);
    return 0;
}

