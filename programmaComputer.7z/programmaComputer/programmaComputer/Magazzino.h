#pragma once
#include "Computer.h"
#include <string>
#include <iostream>
using namespace std;

/*!		\file Magazzino.h
		\class Magazzino
		\brief Classe che dichiara tutti i metodi utilizzati nella classe Magazzino.cpp
*/

class Magazzino
{
	private:
		//! \var totale
		//! \brief Totale dei computer presenti nel magazzino
		int totale;
		//! \var pc
		//! \brief Inserisce una variabile pc di tipo Computer all'interno del catalogo
		Computer* pc;
	
	public:
		 //!	\brief costruttore predefinito
		 Magazzino(void);

		 /*!	\fn aggiungiComputer
				\brief Metodo per aggiungere un computer al catalogo
				\param[in] comp Aggiunge un computer al catalogo tramite l'utilizzo di un array
				\param[in] codice Codice univoco assegnato al computer inserito in quel momento
				\return (totale) Restituisce il numero dei computer presenti all'interno del catalogo
		 */
		 int aggiungiComputer(Computer pc, int codice);

		 /*!	\fn elimina
				\brief Metodo per eliminare un computer tramite il suo codice
				\param[in] cod Fa inserire all'utente il codice del computer da eliminare
				\return (totale) Restituisce il numero dei computer presenti all'interno del catalogo che verra' scalato di 1 una volta eliminato il computer
		 */
		 int elimina(int codice);

		 /*!	\fn ricercaCodice
				\brief Metodo per ricercare la presenza di un computer tramite il codice
				\param[in] codice Fa inserire all'utente il codice del computer da ricercare
				\param[out] pc[i] Vengono stampate le informazioni del computer
		 */
		 void ricercaCodice(int codice);

		 /*!	\fn ricercaMiglioreVelocita
				\brief Metodo per ricercare il computer con la velocita' migliore
				\param[out] pc[i] Vengono stampate le informazioni di quello specifico computer
		 */
		 void ricercaMiglioreVelocita(void);

		 /*!	\fn ricercaMiglioreDimensione
				\brief Metodo per ricercare il computer con la migliore dimensione della RAM
				\param[out] pc[i] Vengono stampate le informazioni di quello specifico computer
		 */
		 void ricercaMiglioreDimensione(void);

		 /*!	\fn ricercaMiglioreDisco
				\brief Metodo per ricercare il computer con il disco piu' capiente
				\param[out] pc[i] Vengono stampate le informazioni di quello specifico computer
		 */
		 void ricercaMiglioreDisco(void);

		 /*!	\fn stampa
			    \brief Metodo che stampa tutti i computer presenti nel catalogo in ordine crescente di codice univoco
		 */
		 void stampa();
};


