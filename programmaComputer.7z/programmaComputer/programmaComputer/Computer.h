#pragma once

#include <iostream>
#include <cstdio>
#include <cstring>

/*!	\file Computer.h
	\class Computer
	\brief Classe che dichiara tutti i metodi utilizzati nella classe Computer.cpp
*/

class Computer
{
	private:
		//! \var modello
		//! \brief Specifica il modello del pc
		std::string modello;

		//! \var marca
		//! \brief Specifica la marca del pc
		std::string marca;

		//! \var disco
		//! \brief Specifica la grandezza del disco fisso del pc
		int disco;

		//! \var vel
		//! \brief Specifica la velocita' del pc
		int vel;

		//! \var ram
		//! \brief Specifica la grandezza della memoria RAM del pc
		int ram;

		//! \var pollici
		//! \brief Specifica la grandezza dello schermo, espressa in pollici, del pc
		int pollici;

		//! \var codice
		//! \brief Specifica il codice univoco del pc
		int codice;

		//! \var anno
		//! \brief Specifica l'anno di fabbrica del pc
		int anno;
	
	public:
		 //!	\brief Costruttore predefinito
		 Computer(void);

		 /*!	\brief Costruttore che inizializza tutte le variabili
				\param[in] marca
				\param[in] modello
				\param[in] velocita'
				\param[in] ram
				\param[in] disco
				\param[in] pollici
				\param[in] anno
				\param[in] codice
		 */

		 Computer(std::string marca, std::string modello, int velocita, int ram, int disco, int pollici, int anno, int codice);

		 /*!	\fn getMarca
				\brief Metodo per prelevare la marca di uno specifico computer
				\return (marca) Restituisce la marca di quel computer
		 */
		 std::string getMarca(void);

		 /*!	\fn getModello
				\brief Metodo per prelevare il modello di uno specifico computer
				\return (modello) Restituisce il modello di quel computer
		 */
		 std::string getModello(void);

		 /*!	\fn getRam
				\brief Metodo per prelevare la grandezza della RAM di uno specifico computer
				 \return (ram) Restituisce la velocita' di quel computer
		 */
		 int getRam(void);

		 /*!	\fn getVel
				\brief Metodo per prelevare la velocita' di uno specifico computer
				\return (vel) Restituisce la velocita' di quel computer
		*/
		 int getVel(void);

		 /*!	\fn getDisco
				\brief Metodo per prelevare la grandezza del disco fisso di uno specifico computer
				\return (vel) Restituisce la grandezza del disco di quel computer
		 */
		 int getDisco(void);

		 /*!	\fn getPollici
				\brief Metodo per prelevare la grandezza dello schermo di uno specifico computer
				\return (pollici) Restituisce la grandezza dello schermo di uno specifico computer
		 */
		 int getPollici(void);

		 /*!	\fn getAnno
				\brief Metodo per prelevare l'anno di uscita di uno specifico computer
				\return (anno) Restituisce l'anno in cui il computer e' uscito dalla casa produttrice
		 */
		 int getAnno(void);

		 /*!	\fn getCodice
				\brief Metodo per prelevare il codice univoco di uno specifico computer
				\return (codice) Restituisce il codice di quel computer
		 */
		 int getCodice(void);
};



